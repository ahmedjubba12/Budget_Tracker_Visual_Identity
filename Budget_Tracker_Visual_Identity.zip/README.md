# Budget Tracker — Visual Identity

## Project overview
This project presents a polished visual design for a personal Budget Tracker. The interface uses a calm teal, navy, and off-white palette, clear typography, and card-based sections to make expense information easy to scan.

> **Important:** The original Week 1–2 project files were not supplied when this version was prepared. This ZIP therefore contains a standalone visual-design template rather than a verified update to your existing project. If your earlier project has working expense-entry functionality, retain its existing HTML and functionality and transfer the styles from `style.css` to the matching elements before submission.

## Files
- `index.html` — page content and existing-style interface areas: page heading, budget summary, Add Expense form, and Expense Table.
- `style.css` — visual styling, including colors, Google Fonts, responsive layout, form controls, table appearance, and CSS box-model spacing.
- `README.md` — project explanation and setup notes.

## Design choices
- **Color palette:** deep navy for primary text, teal for actions and accents, pale mint for supporting surfaces, and warm off-white for the page background.
- **Typography:** Manrope is used for headings; DM Sans is used for body text, labels, inputs, buttons, and table content. Both are loaded from Google Fonts.
- **Form styling:** consistent input height, padding, borders, rounded corners, and visible keyboard-focus states.
- **Table styling:** tinted header, padded cells, subtle borders, alternating row backgrounds, and a horizontally scrollable wrapper on small screens.
- **CSS box model:** `box-sizing: border-box`, margins between sections, padding inside cards and controls, borders for separation, and rounded corners.

## How to view
1. Extract the ZIP file.
2. Open `index.html` in a web browser.
3. Keep `index.html` and `style.css` in the same folder.
4. An internet connection is needed to load the Google Fonts; system fallbacks are provided.

## Note on functionality
This deliverable focuses on visual design. The sample Add Expense button is presentational and does not save or add expense records. Connect it to the functionality from your earlier Budget Tracker project rather than presenting this template as a completed functional tracker.
